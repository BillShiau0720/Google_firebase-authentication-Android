package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.content.ContentValues.TAG;

public class AddvalueActivity extends AppCompatActivity {
    String Uid,money,codemoney;
    int addmoney,frequency;
    TextView txv;
    EditText edt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addvalue);

        txv=findViewById(R.id.textView22);
        edt=findViewById(R.id.editTextTextPersonName2);

        String getRecord = getSharedPreferences("record", MODE_PRIVATE)
                .getString("Uid", "沒讀到資料就會顯示這段文字");
        Uid=getRecord;
        String getRecord2 = getSharedPreferences("code", MODE_PRIVATE)
                .getString("code", "null");
        Uid=getRecord;
        String code = getRecord2;
        if(code.equals("null")){
            edt.setText("");
        }else{
            edt.setText(code);
        }



        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("user");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                money=dataSnapshot.child(Uid).child("money").getValue().toString();
                addmoney=Integer.parseInt(money);
                txv.setText("倉鼠幣:"+money);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    public void addmoney(View v){
        String codenum=edt.getText().toString();
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("code");
        mDatabase.child(codenum).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    codemoney = "0";
                    Log.e("firebase", "Error getting data", task.getException());
                } else {

                    codemoney = String.valueOf(task.getResult().getValue());
                    Log.d("firebase", String.valueOf(task.getResult().getValue()));
                    if(codemoney.equals("1000") || codemoney.equals("5000")){
                        frequency = Integer.parseInt(codemoney);
                        int lastmoney = addmoney + frequency;
                        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("user");
                        mDatabase.child(Uid).child("money").setValue(lastmoney);
                        DatabaseReference mDatabase2 = FirebaseDatabase.getInstance().getReference("code");
                        mDatabase2.child(codenum).setValue("");
                    }else{
                        AlertDialog.Builder builder = new AlertDialog.Builder(AddvalueActivity.this);
                        builder.setMessage("代碼輸入錯誤");
                        builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        });
                        AlertDialog dialog = builder.create();
                        dialog.show();
                    }
                }
            }
        });
    }


    public void scan(View v){
        Intent intent = new Intent();
        intent.setClass(AddvalueActivity.this,ScanActivity.class);
        startActivity(intent);
        AddvalueActivity.this.finish();
    }

    public void mainpage(View v){
        Intent intent = new Intent();
        intent.setClass(AddvalueActivity.this,HomeActivity.class);
        startActivity(intent);
        AddvalueActivity.this.finish();
    }


}