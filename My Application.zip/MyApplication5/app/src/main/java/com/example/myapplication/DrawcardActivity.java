package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;

public class DrawcardActivity extends AppCompatActivity {
    String Uid,im5color,heroname;
    TextView txv;
    ImageView im5;
    Button drawone,drawten,retry,mainpagebtn;
    int hero;
    int frequency=0;
    int nowmoney=0;
    String[] bluename = {"倉鼠騎士","倉鼠護衛","倉鼠將軍","倉鼠公主","倉鼠劍士"};
    String[] greenname = {"小倉鼠","倉鼠農夫","倉鼠漁夫","老倉鼠","倉鼠老師"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawcard);


        txv=findViewById(R.id.textView11);
        mainpagebtn=findViewById(R.id.button10);
        drawone=findViewById(R.id.button6);
        drawten=findViewById(R.id.button7);
        retry=findViewById(R.id.button9);
        im5=findViewById(R.id.imageView);
        retry.setVisibility(View.GONE);
        im5.setBackgroundColor(Color.WHITE);
        im5color = "";


        //取得內存之Uid資料
        String getRecord = getSharedPreferences("record", MODE_PRIVATE)
                .getString("Uid", "沒讀到資料就會顯示這段文字");
        Uid = getRecord;

        //即時取得使用者倉鼠幣
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("user");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String money=dataSnapshot.child(Uid).child("money").getValue().toString();
                nowmoney=Integer.parseInt(money);
                txv.setText("倉鼠幣 : "+money);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    //震動
    public void setVibrate(int time){
        Vibrator myVibrator = (Vibrator) getSystemService(Service.VIBRATOR_SERVICE);
        myVibrator.vibrate(time);
    }

    //單抽
    public void drawone(View v){
        if(nowmoney>=10){
            frequency= 10;
            costmoney();
            mainpagebtn.setVisibility(View.GONE);
            int card= (int)(Math.random()* 99 + 1);
            hero = (int) (Math.random() * 4 + 0);
            if(card==7){
                im5.setBackgroundColor(Color.RED);
                im5color="red";
                setVibrate(3000);
            }else if(card==50||card==81||card==90||card==31||card==53||card==12||card==25||card==44||card==98||card==63){
                im5.setBackgroundColor(Color.BLUE);
                im5color="blue";
                setVibrate(1000);
            }else{
                im5.setBackgroundColor(Color.GREEN);
                im5color="green";
            }
            retry.setVisibility(View.VISIBLE);
            drawone.setEnabled(false);
            drawten.setEnabled(false);
        }else{
            AlertDialog.Builder builder = new AlertDialog.Builder(DrawcardActivity.this);
            builder.setTitle("提醒");
            builder.setMessage("你的倉鼠幣不足!!");
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }

    //十抽
    public void drawten(View v){
        if(nowmoney>=100){
            frequency=10*10;
            costmoney();
            Intent intent = new Intent();
            intent.setClass(DrawcardActivity.this,DrawtenActivity.class);
            startActivity(intent);
        }else {
            AlertDialog.Builder builder = new AlertDialog.Builder(DrawcardActivity.this);
            builder.setTitle("提醒");
            builder.setMessage("你的倉鼠幣不足!!");
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }

    }

    //顯示抽到之獎項名稱
    public void onclik(View v){
        if(im5color!="") {
            if (im5color.equals("red")) {
                heroname = "倉鼠皇后";
            } else if (im5color.equals("blue")) {
                heroname = bluename[hero];
            } else if (im5color.equals("green")) {
                heroname = greenname[hero];
            }
            retry.setVisibility(View.VISIBLE);
            AlertDialog.Builder builder = new AlertDialog.Builder(DrawcardActivity.this);
            builder.setMessage("恭喜你抽到了" + heroname);
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }else{
            Toast.makeText(this, "請點擊一抽或十抽", Toast.LENGTH_LONG).show();
        }
    }

    //再抽一次
    public void retry(View v){
        mainpagebtn.setVisibility(View.VISIBLE);
        retry.setVisibility(View.GONE);
        im5.setBackgroundColor(Color.WHITE);
        drawone.setEnabled(true);
        drawten.setEnabled(true);
        im5color="";
        heroname = "";
        hero=0;
    }

    //機率
    public void Probability(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(DrawcardActivity.this);
        builder.setTitle("角色機率");
        builder.setMessage("倉鼠皇后 1% \n"+"倉鼠騎士 2%  倉鼠護衛 2%  倉鼠將軍 2%  倉鼠公主 2%  倉鼠劍士 2%\n");
        builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //扣錢
    public void costmoney(){
        int lastmoney=nowmoney-frequency;

        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("user");
        mDatabase.child(Uid).child("money").setValue(lastmoney);
    }

    //回主頁
    public void mainpage(View v){
        finish();
    }


}