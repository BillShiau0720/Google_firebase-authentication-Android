package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class DrawtenActivity extends AppCompatActivity {
    String heroname,im1color,im2color,im3color,im4color,im5color,im6color,im7color,im8color,im9color,im10color;
    ImageView im1,im2,im3,im4,im11,im6,im7,im8,im9,im10;
    TextView txv1,txv2,txv3,txv4,txv5,txv6,txv7,txv8,txv9,txv10;
    Button btnok;
    int hero,hero2,hero3,hero4,hero5,hero6,hero7,hero8,hero9,hero10;
    int opentime=0;
    String[] bluename = {"倉鼠騎士","倉鼠護衛","倉鼠將軍","倉鼠公主","倉鼠劍士"};
    String[] greenname = {"小倉鼠","倉鼠農夫","倉鼠漁夫","老倉鼠","倉鼠老師"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawten);

        im1=findViewById(R.id.imageView2);
        im2=findViewById(R.id.imageView3);
        im3=findViewById(R.id.imageView4);
        im4=findViewById(R.id.imageView7);
        im6=findViewById(R.id.imageView8);
        im7=findViewById(R.id.imageView9);
        im8=findViewById(R.id.imageView10);
        im9=findViewById(R.id.imageView11);
        im10=findViewById(R.id.imageView12);
        im11=findViewById(R.id.imageView13);

        txv1=findViewById(R.id.textView12);
        txv2=findViewById(R.id.textView13);
        txv3=findViewById(R.id.textView14);
        txv4=findViewById(R.id.textView15);
        txv5=findViewById(R.id.textView16);
        txv6=findViewById(R.id.textView17);
        txv7=findViewById(R.id.textView18);
        txv8=findViewById(R.id.textView19);
        txv9=findViewById(R.id.textView20);
        txv10=findViewById(R.id.textView21);
        btnok=findViewById(R.id.button11);
        opentime=0;

        c1();
        c2();
        c3();
        c4();
        c5();
        c6();
        c7();
        c8();
        c9();
        c10();
    }

    public void setVibrate(int time){
        Vibrator myVibrator = (Vibrator) getSystemService(Service.VIBRATOR_SERVICE);
        myVibrator.vibrate(time);
    }

    //顯示十張卡抽到之顏色
    public void c1(){
        int card= (int)(Math.random()* 99 + 1);
        hero = (int) (Math.random() * 4 + 0);
        if(card==7){
            im1.setBackgroundColor(Color.RED);
            im1color="red";
        }else if(card==50||card==81||card==90||card==31||card==53||card==12||card==25||card==44||card==98||card==63){
            im1.setBackgroundColor(Color.BLUE);
            im1color="blue";
        }else{
            im1.setBackgroundColor(Color.GREEN);
            im1color="green";
        }
    }
    public void c2(){
        int card1= (int)(Math.random()* 99 + 1);
        hero2 = (int) (Math.random() * 4 + 0);
        if(card1==7){
            im2.setBackgroundColor(Color.RED);
            im2color="red";
        }else if(card1==50||card1==81||card1==90||card1==31||card1==53||card1==12||card1==25||card1==44||card1==98||card1==63){
            im2.setBackgroundColor(Color.BLUE);
            im2color="blue";
        }else{
            im2.setBackgroundColor(Color.GREEN);
            im2color="green";
        }
    }
    public void c3(){
        int card2= (int)(Math.random()* 99 + 1);
        hero3 = (int) (Math.random() * 4 + 0);
        if(card2==7){
            im3.setBackgroundColor(Color.RED);
            im3color="red";
        }else if(card2==50||card2==81||card2==90||card2==31||card2==53||card2==12||card2==25||card2==44||card2==98||card2==63){
            im3.setBackgroundColor(Color.BLUE);
            im3color="blue";

        }else{
            im3.setBackgroundColor(Color.GREEN);
            im3color="green";
        }
    }
    public void c4(){
        int card3= (int)(Math.random()* 99 + 1);
        hero4 = (int) (Math.random() * 4 + 0);
        if(card3==7){
            im4.setBackgroundColor(Color.RED);
            im4color="red";
        }else if(card3==50||card3==81||card3==90||card3==31||card3==53||card3==12||card3==25||card3==44||card3==98||card3==63){
            im4.setBackgroundColor(Color.BLUE);
            im4color="blue";
        }else{
            im4.setBackgroundColor(Color.GREEN);
            im4color="green";
        }
    }
    public void c5(){
        int card4= (int)(Math.random()* 99 + 1);
        hero5 = (int) (Math.random() * 4 + 0);
        if(card4==7){
            im6.setBackgroundColor(Color.RED);
            im5color="red";
        }else if(card4==50||card4==81||card4==90||card4==31||card4==53||card4==12||card4==25||card4==44||card4==98||card4==63){
            im6.setBackgroundColor(Color.BLUE);
            im5color="blue";
        }else{
            im6.setBackgroundColor(Color.GREEN);
            im5color="green";
        }
    }
    public void c6(){
        int card5= (int)(Math.random()* 99 + 1);
        hero6 = (int) (Math.random() * 4 + 0);
        if(card5==7){
            im7.setBackgroundColor(Color.RED);
            im6color="red";
        }else if(card5==50||card5==81||card5==90||card5==31||card5==53||card5==12||card5==25||card5==44||card5==98||card5==63){
            im7.setBackgroundColor(Color.BLUE);
            im6color="blue";
        }else{
            im7.setBackgroundColor(Color.GREEN);
            im6color="green";
        }
    }
    public void c7(){
        int card6= (int)(Math.random()* 99 + 1);
        hero7 = (int) (Math.random() * 4 + 0);
        if(card6==7){
            im8.setBackgroundColor(Color.RED);
            im7color="red";
        }else if(card6==50||card6==81||card6==90||card6==31||card6==53||card6==12||card6==25||card6==44||card6==98||card6==63){
            im8.setBackgroundColor(Color.BLUE);
            im7color="blue";
        }else{
            im8.setBackgroundColor(Color.GREEN);
            im7color="green";
        }
    }
    public void c8(){
        int card7= (int)(Math.random()* 99 + 1);
        hero8 = (int) (Math.random() * 4 + 0);
        if(card7==7){
            im9.setBackgroundColor(Color.RED);
            im8color="red";
        }else if(card7==50||card7==81||card7==90||card7==31||card7==53||card7==12||card7==25||card7==44||card7==98||card7==63){
            im9.setBackgroundColor(Color.BLUE);
            im8color="blue";
        }else{
            im9.setBackgroundColor(Color.GREEN);
            im8color="green";
        }
    }
    public void c9(){
        int card8= (int)(Math.random()* 99 + 1);
        hero9 = (int) (Math.random() * 4 + 0);
        if(card8==7){
            im10.setBackgroundColor(Color.RED);
            im9color="red";
        }else if(card8==50||card8==81||card8==90||card8==31||card8==53||card8==12||card8==25||card8==44||card8==98||card8==63){
            im10.setBackgroundColor(Color.BLUE);
            im9color="blue";
        }else{
            im10.setBackgroundColor(Color.GREEN);
            im9color="green";
        }
    }
    public void c10(){
        int card10= (int)(Math.random()* 99 + 1);
        hero10 = (int) (Math.random() * 4 + 0);
        if(card10==7){
            im11.setBackgroundColor(Color.RED);
            im10color="red";
        }else if(card10==50||card10==81||card10==90||card10==31||card10==53||card10==12||card10==25||card10==44||card10==98||card10==63){
            im11.setBackgroundColor(Color.BLUE);
            im10color="blue";
        }else{
            im11.setBackgroundColor(Color.GREEN);
            im10color="green";
        }
    }

    //顯示抽到之獎項名稱
    public void onclik1(View v) {
        if(txv1.getText().toString()==null || txv1.getText().toString().equals("")){
            if (im1color != "") {
                if (im1color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv1.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im1color.equals("blue")) {
                    heroname = bluename[hero];
                    txv1.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im1color.equals("green")) {
                    heroname = greenname[hero];
                    txv1.setTextColor(Color.GREEN);
                }
            }
            txv1.setText(heroname);
            opentime=opentime+1;
        }
    }
    public void onclik2(View v) {
        if(txv2.getText().toString()==null || txv2.getText().toString().equals("")){
            if (im2color != "") {
                if (im2color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv2.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im2color.equals("blue")) {
                    heroname = bluename[hero2];
                    txv2.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im2color.equals("green")) {
                    heroname = greenname[hero2];
                    txv2.setTextColor(Color.GREEN);
                }
            }
            txv2.setText(heroname);
            opentime=opentime+1;
        }
    }
    public void onclik3(View v) {
        if(txv3.getText().toString()==null || txv3.getText().toString().equals("")){
            if (im3color != "") {
                if (im3color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv3.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im3color.equals("blue")) {
                    heroname = bluename[hero3];
                    txv3.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im3color.equals("green")) {
                    heroname = greenname[hero3];
                    txv3.setTextColor(Color.GREEN);
                }
            }
            txv3.setText(heroname);
            opentime=opentime+1;
        }
    }
    public void onclik4(View v) {
        if(txv4.getText().toString()==null || txv4.getText().toString().equals("")){
            if (im4color != "") {
                if (im4color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv4.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im4color.equals("blue")) {
                    heroname = bluename[hero4];
                    txv4.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im4color.equals("green")) {
                    heroname = greenname[hero4];
                    txv4.setTextColor(Color.GREEN);
                }
            }
            txv4.setText(heroname);
            opentime=opentime+1;
        }
    }
    public void onclik5(View v) {
        if(txv5.getText().toString()==null || txv5.getText().toString().equals("")){
            if (im5color != "") {
                if (im5color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv5.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im5color.equals("blue")) {
                    heroname = bluename[hero5];
                    txv5.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im5color.equals("green")) {
                    heroname = greenname[hero5];
                    txv5.setTextColor(Color.GREEN);
                }
            }
            txv5.setText(heroname);
            opentime=opentime+1;
        }
    }
    public void onclik6(View v) {
        if(txv6.getText().toString()==null || txv6.getText().toString().equals("")){
            if (im6color != "") {
                if (im6color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv6.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im6color.equals("blue")) {
                    heroname = bluename[hero6];
                    txv6.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im6color.equals("green")) {
                    heroname = greenname[hero6];
                    txv6.setTextColor(Color.GREEN);
                }
            }
            txv6.setText(heroname);
            opentime=opentime+1;
        }

    }
    public void onclik7(View v) {
        if(txv7.getText().toString()==null || txv7.getText().toString().equals("")){
            if (im7color != "") {
                if (im7color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv7.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im7color.equals("blue")) {
                    heroname = bluename[hero7];
                    txv7.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im7color.equals("green")) {
                    heroname = greenname[hero7];
                    txv7.setTextColor(Color.GREEN);
                }
            }
            txv7.setText(heroname);
            opentime=opentime+1;
        }
    }
    public void onclik8(View v) {
        if(txv8.getText().toString()==null || txv8.getText().toString().equals("")){
            if (im8color != "") {
                if (im8color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv8.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im8color.equals("blue")) {
                    heroname = bluename[hero8];
                    txv8.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im8color.equals("green")) {
                    heroname = greenname[hero8];
                    txv8.setTextColor(Color.GREEN);
                }
            }
            txv8.setText(heroname);
            opentime=opentime+1;
        }

    }
    public void onclik9(View v) {
        if(txv9.getText().toString()==null || txv9.getText().toString().equals("")){
            if (im9color != "") {
                if (im9color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv9.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im9color.equals("blue")) {
                    heroname = bluename[hero9];
                    txv9.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im9color.equals("green")) {
                    heroname = greenname[hero9];
                    txv9.setTextColor(Color.GREEN);
                }
            }
            txv9.setText(heroname);
            opentime=opentime+1;
        }
    }
    public void onclik10(View v) {
        if(txv10.getText().toString()==null || txv10.getText().toString().equals("")){
            if (im10color != "") {
                if (im10color.equals("red")) {
                    heroname = "倉鼠皇后";
                    txv10.setTextColor(Color.RED);
                    setVibrate(3000);
                } else if (im10color.equals("blue")) {
                    heroname = bluename[hero10];
                    txv10.setTextColor(Color.BLUE);
                    setVibrate(1000);
                } else if (im10color.equals("green")) {
                    heroname = greenname[hero10];
                    txv10.setTextColor(Color.GREEN);
                }
            }
            txv10.setText(heroname);
            opentime=opentime+1;
        }
    }

    public void skip(View v){
        if(opentime<10){
            AlertDialog.Builder builder = new AlertDialog.Builder(DrawtenActivity.this);
            builder.setTitle("提醒");
            builder.setMessage("有卡片沒有開啟，確定要跳過?");
            builder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                }
            });
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    onclik1(v);
                    onclik2(v);
                    onclik3(v);
                    onclik4(v);
                    onclik5(v);
                    onclik6(v);
                    onclik7(v);
                    onclik8(v);
                    onclik9(v);
                    onclik10(v);
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }else{
            finish();
        }

    }

    //禁用返回鍵
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return true;
        }
        return false;
    }
}