package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.content.ContentValues.TAG;

public class HomeActivity extends AppCompatActivity {
    TextView txvname,txvmoney;
    String name,Uid,money;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        txvname=findViewById(R.id.textView10);
        txvmoney=findViewById(R.id.textView9);

        String getRecord = getSharedPreferences("record", MODE_PRIVATE)
                .getString("Uid", "沒讀到資料就會顯示這段文字");
        Uid=getRecord;

        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("user");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                money=dataSnapshot.child(Uid).child("money").getValue().toString();
                name=dataSnapshot.child(Uid).child("username").getValue().toString();
                txvname.setText("玩家名稱:\n"+name);
                txvmoney.setText("倉鼠幣:\n"+money);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    //登出
    public void close(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        builder.setMessage("確定要登出?");
        builder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.setNegativeButton("登出", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int id) {
                Intent intent = new Intent();
                intent.setClass(HomeActivity.this,LoginActivity2.class);
                startActivity(intent);
                HomeActivity.this.finish();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();

    }

    //版本記錄
    public void Versionrecord(View v){
        Intent intent = new Intent();
        intent.setClass(HomeActivity.this,VersionrecordActivity.class);
        startActivity(intent);
    }

    //開啟抽卡介面
    public void drawcard(View v){
        Intent intent = new Intent();
        intent.setClass(HomeActivity.this,DrawcardActivity.class);
        startActivity(intent);
    }

    //開啟加值介面
    public void addvalue(View v){
        SharedPreferences record = getSharedPreferences("code", MODE_PRIVATE);    //儲存Uid
        record.edit()
                .putString("code", "null")
                .apply();
        Intent intent = new Intent();
        intent.setClass(HomeActivity.this,AddvalueActivity.class);
        startActivity(intent);
    }

    //禁用返回鍵
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
            builder.setMessage("確定要關閉程式?");
            builder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                }
            });
            builder.setNegativeButton("確認", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    android.os.Process.killProcess(android.os.Process.myPid());         //關閉程式
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
            return true;
        }
        return false;
    }
}