package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity {
    String gameversion = "V1.5.1";       //本地遊戲版本
    ProgressBar progBar;
    TextView txv,txv2;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("server");
    private DatabaseReference mDatabase;
    Handler handler = new Handler();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // myRef.setValue("Hello, World!");

        progBar = findViewById(R.id.progressBar);
        txv= findViewById(R.id.textView);
        txv2= findViewById(R.id.textView2);
        progBar.setMax(100); //設定最大值
        progBar.setProgress(30); //設定主要進度值
        txv.setText("檢查網路連線...");
        checknet();





    }
    public void checknet(){
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("server");
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {   //讀取

                txv2.setText("連線狀態 : ok\n");
                handler.postDelayed(new Runnable() {             //delay
                    public void run() {
                        progBar.setProgress(50);
                        txv.setText("檢查伺服器狀態...");
                        String state=dataSnapshot.child("state").getValue().toString();
                        txv2.setText(txv2.getText()+"伺服器狀態 : "+state+"\n");
                    }
                }, 3000);
                handler.postDelayed(new Runnable() {
                    public void run() {
                        txv.setText("檢查程式版本...");
                        progBar.setProgress(80);
                        String ver=dataSnapshot.child("ver").getValue().toString();
                        if(ver.equals(gameversion)) {
                            txv2.setText(txv2.getText() + "遊戲版本 : " + ver);
                            txv.setText("即將完成...");
                            progBar.setProgress(100);
                            handler.postDelayed(new Runnable() {             //delay
                                public void run() {
                                    Intent intent = new Intent();
                                    intent.setClass(MainActivity.this,LoginActivity2.class);
                                    startActivity(intent);
                                    MainActivity.this.finish();
                                }
                            }, 3000);
                        }else{
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                            builder.setMessage("必須要更新程式!!");
                            builder.setPositiveButton("更新", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    Intent intent = new Intent();
                                    intent.setAction(Intent.ACTION_VIEW);
                                    intent.setData(Uri.parse("https://drive.google.com/drive/folders/1rQPhVr8M1uKXHq2bDNKmgty45kP5_kM8?usp=sharing"));
                                    startActivity(intent);

                                }
                            });
                            builder.setNegativeButton("關閉程式", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int id) {
                                    android.os.Process.killProcess(android.os.Process.myPid());         //關閉程式
                                }
                            });
                            AlertDialog dialog = builder.create();
                            dialog.show();
                        }
                    }
                }, 3000);
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }


}