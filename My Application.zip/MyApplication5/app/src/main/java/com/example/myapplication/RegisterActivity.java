package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    EditText name,account,password;
    String user="";
    String uaccount="";





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name=findViewById(R.id.editTextTextPersonName);
        account=findViewById(R.id.Edittext);
        password=findViewById(R.id.Edittext2);


    }

    public void checkname(View v){          //檢查名稱
        String test = name.getText().toString();
        if(test.isEmpty() || "".equals(test.trim())) {
            AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
            builder.setMessage("玩家名稱不能空白");
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        }else if (account.length() >= 5 && password.length() >= 5) {
            String name1=name.getText().toString();
            DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("name");
            mDatabase.child(""+name1).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (!task.isSuccessful()) {
                        user="null";
                        Log.e("firebase", "Error getting data", task.getException());
                    }
                    else {

                        user=String.valueOf(task.getResult().getValue());
                        Log.d("firebase", String.valueOf(task.getResult().getValue()));
                        if(user.equals("true")){
                            AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                            builder.setMessage("此名稱已有人使用");
                            builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            });
                            AlertDialog dialog = builder.create();
                            dialog.show();
                        }else if(user.equals("null")){
                            checkaccount();
                        }
                    }
                }
            });
        } else {
            Toast.makeText(this, "帳號或密碼字元太少", Toast.LENGTH_LONG).show();
        }
    }

    public void checkaccount(){         //檢查帳號
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("accnum");
        mDatabase.child(account.getText().toString()).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    uaccount="null";
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    uaccount=String.valueOf(task.getResult().getValue());
                    Log.d("firebase", String.valueOf(task.getResult().getValue()));
                    if(uaccount.equals("true")){
                        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                        builder.setMessage("此帳號已有人使用");
                        builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        });
                        AlertDialog dialog = builder.create();
                        dialog.show();
                    }else if(uaccount.equals("null")){
                        reg();
                    }
                }
            }
        });
    }

    public void reg(){          //註冊使用者資訊
        int num1;
        String userid;
        num1 = (int) (Math.random() * 1000000000) + 1;
        userid =""+num1;
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef1 = database.getReference("accnum");
        myRef1.child(account.getText().toString()).setValue("true");
        DatabaseReference myRef2 = database.getReference("name");
        myRef2.child(name.getText().toString()).setValue("true");
        DatabaseReference myRef3 = database.getReference("useraccount");            //儲存用戶數值
        myRef3.child(account.getText().toString()+password.getText().toString()).setValue(userid);
        DatabaseReference myRef = database.getReference("user");            //儲存用戶數值
        myRef.child(userid.toString()).child("username").setValue(name.getText().toString());
        myRef.child(userid.toString()).child("account").setValue(account.getText().toString());
        myRef.child(userid.toString()).child("password").setValue(password.getText().toString());
        myRef.child(userid.toString()).child("money").setValue("1000");
        myRef.child(userid.toString()).child("rank").setValue("1000");
        AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
        builder.setMessage("註冊成功!!");
        builder.setPositiveButton("確認", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Intent intent = new Intent();
                intent.setClass(RegisterActivity.this,LoginActivity2.class);
                startActivity(intent);
                RegisterActivity.this.finish();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

}