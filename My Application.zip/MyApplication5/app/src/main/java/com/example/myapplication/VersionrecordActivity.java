package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class VersionrecordActivity extends AppCompatActivity {
    TextView txv,txv2;
    String[] vercor = {"修正十抽震動異常，新增主頁無法使用返回鍵","新增加值功能(代碼與QR)","新增版本記錄(可供使用者瀏覽歷代版本更新內容)","改善抽卡與扣倉鼠幣的流暢度","1.修正會重複抽到同顏色角色之問題 \n 2.修正無法即時看到扣完錢後的金額","1.新增抽卡系統(十抽)\n 2.新增扣錢機制","新增抽卡系統(單抽)","修正註冊使用者名稱與帳號可以重複使用的問題","修正畫面旋轉問題","1.程式UI大翻新\n 2.更改ICON","使用者登入後主頁面完成","修正帳號與密碼可以輸入非法文字的問題","1.使用者可以進行註冊與登入\n 2.設計使用者資料架構","修正程式取到空值會掛的問題","登入與注冊頁面完成","檢查連線頁面完成"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_versionrecord);

        txv=findViewById(R.id.textView23);
        txv2=findViewById(R.id.textView24);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter =
                ArrayAdapter.createFromResource(this,
                        R.array.planets_array,
                        android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(2, false);
        spinner.setOnItemSelectedListener(spnOnItemSelected);
    }
    private AdapterView.OnItemSelectedListener spnOnItemSelected
            = new AdapterView.OnItemSelectedListener() {
        public void onItemSelected(AdapterView<?> parent, View view,
                                   int pos, long id) {
            int sPos=Integer.parseInt(String.valueOf(pos));         //取得選取之位置
            String content=parent.getItemAtPosition(pos).toString();
            txv.setText(content);
            txv2.setText(vercor[sPos]);
        }
        public void onNothingSelected(AdapterView<?> parent) {
            //
        }
    };

    public void exit(View v){
        finish();
    }
}